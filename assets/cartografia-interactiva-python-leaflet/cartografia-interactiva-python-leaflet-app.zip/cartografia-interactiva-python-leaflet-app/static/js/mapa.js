const mapa = L.map('mi_mapa').setView([40.416775, -3.703790], 5); 

L.tileLayer('/static/tiles/{z}/{x}/{y}.png', {
    minZoom: 3,
    maxZoom: 5,
    attribution: 'OpenStreetMap, CARTO'
}).addTo(mapa); 

Promise.all([
    fetch('/static/data/puntos.json').then(res => res.json()),
    fetch('/static/data/rutas.json').then(res => res.json())
])
.then(([puntos, rutas]) => {
    
    const mapaPuntos = {};
    puntos.forEach(punto => {
        mapaPuntos[punto.name] = punto;
    });

    puntos.forEach(punto => {
        const iconoPunto = L.divIcon({
            className: 'marcador-punto',
            iconSize: [8, 8],
            iconAnchor: [4, 4]
        });

        const marcador = L.marker(punto.coordinates, { icon: iconoPunto }).addTo(mapa);
        
        marcador.bindPopup(`<b>${punto.name}</b><br>${punto.country}`, {
            className: 'popup'
        });
    });

    rutas.forEach(trayecto => {
        const puntoOrigen = mapaPuntos[trayecto.from];
        const puntoDestino = mapaPuntos[trayecto.to];

        if (puntoOrigen && puntoDestino) {
            const coordenadasLinea = [
                puntoOrigen.coordinates,
                puntoDestino.coordinates
            ];

            L.polyline(coordenadasLinea, {
                className: 'linea-ruta'
            }).addTo(mapa);
        }
    });

    window.mapaObjeto = mapa;        
    window.datosRutas = rutas;       
    window.datosPuntos = mapaPuntos; 
    
    window.dispatchEvent(new Event('mapaBaseListo'));
})
.catch(error => console.error('Error al cargar o procesar los datos geoespaciales:', error));