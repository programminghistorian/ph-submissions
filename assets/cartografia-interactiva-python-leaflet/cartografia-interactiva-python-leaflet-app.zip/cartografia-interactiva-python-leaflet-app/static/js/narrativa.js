const textosHistoricos = {
    "Lisboa": `<b>Lisboa (Origen)</b><br><br>El viaje se inició desde el río Tajo, en frente de la Torre de Belém en Lisboa, a las cuatro y media de la tarde del 30 de marzo de 1922, en un avión monomotor Fairey IIID Mk II especialmente diseñado para este viaje, equipado con un motor Rolls-Royce y bautizado con el nombre de <i>Lusitania</i>. Sacadura Cabral ejercía las funciones de piloto y Gago Coutinho las de navegante. Este último había creado —y empleó durante el viaje— un sextante al que había adaptado un horizonte artificial. Este invento revolucionó la navegación aérea de la época.`,
    "Las Palmas de Gran Canaria": `<b>Gran Canaria</b><br><br>La primera etapa del viaje concluyó el mismo día en Las Palmas de Gran Canaria (Islas Canarias, España), donde los dos tripulantes notaron que el avión amarrado había consumido más combustible del que tenían pensado.`,
    "São Vicente": `<b>São Vicente</b><br><br>El 5 de abril partieron rumbo a la isla de São Vicente, en el archipiélago de Cabo Verde, recorriendo 850 millas. Allí tuvieron que permanecer hasta el 17 de abril debido a reparaciones en el hidroavión.`,
    "Praia": `<b>Praia</b><br><br>De ahí partieron a la cercana isla de Santiago, y desde su capital Praia pusieron rumbo al archipiélago de San Pedro y San Pablo, ya en aguas brasileñas.`,
    "Fernando de Noronha": `<b>Fernando de Noronha</b><br><br>Llegarían a San Pedro y San Pablo sin ayuda del viento el día 18. Debido al mar revuelto que había en ese lugar, el Lusitania perdió uno de sus flotadores. Los dos tripulantes fueron recogidos por un crucero de la Marina Portuguesa, que los condujo a Fernando de Noronha (archipiélago brasileño). A pesar de estar exhaustos después de haber recorrido 1700 kilómetros, y tras su amerizaje accidentado, habían llegado a aquel punto del Atlántico Sur contando únicamente con el sextante con horizonte artificial creado por Gago Coutinho.`,
    "Recife": `<b>Recife</b><br><br>Tras reanudar el vuelo con un nuevo aparato, los aviadores alcanzaron las playas de Recife en la costa continental brasileña, donde fueron recibidos con enorme entusiasmo por la población local, marcando el éxito del cruce oceánico.`,
    "Salvador de Bahía": `<b>Salvador de Bahía</b><br><br>Muy poco después, llegaron a Salvador de Bahía siguiendo su rumbo hacia el sur. Las dificultades técnicas continuaban, pero el sistema de navegación astronómica demostraba una precisión impecable en cada etapa.`,
    "Porto Seguro": `<b>Porto Seguro</b><br><br>Su siguiente parada fue Porto Seguro. En este punto de la costa, la expedición portuguesa ya había captado la atención de los medios internacionales, que seguían día a día las hazañas de los pilotos.`,
    "Vitória": `<b>Vitória</b><br><br>A escasa distancia de su meta, el hidroavión tocó aguas en Vitória. La tripulación realizó las últimas comprobaciones técnicas antes de emprender el tramo final hacia la capital cultural e histórica del país.`,
    "Río de Janeiro": `<b>Río de Janeiro (Destino Final)</b><br><br>El 17 de junio de 1922 amerizaron en la Bahía de Guanabara, en Río de Janeiro, donde Alberto Santos Dumont, considerado uno de los pioneros de la aviación, les abrazó emocionado.<br><br>Aclamados efusivamente como héroes en todas las ciudades brasileñas donde amerizaron, Gago Coutinho y Sacadura Cabral habían concluido con éxito la primera travesía aérea del Atlántico Sur, y por primera vez se había volado sobre el Océano Atlántico únicamente con la ayuda de la navegación astronómica.`
};

let capasRutasDibujadas = [];
let marcadorViajeroInstancia = null;

const iconoViajero = L.divIcon({
    html: `<div class="pulso-viajero"></div>`,
    className: 'marcador-viajero',
    iconSize: [20, 20],
    iconAnchor: [10, 10]
});

function inicializarCapaNarrativa() {
    const modalHTML = `
        <div id="modal-bienvenida" class="modal-overlay">
            <div class="modal-content">
                <h2>El primer vuelo a través del Atlántico Sur (1922)</h2>
                <p>Descubre la primera travesía aérea del Atlántico Sur. Un viaje de 79 días y 8.383 kilómetros que revolucionó la navegación aérea gracias a la ciencia y la tenacidad de los aviadores portugueses Gago Coutinho y Sacadura Cabral.</p>
                <button id="btn-comenzar" class="btn-play">
                    <svg viewBox="0 0 24 24" width="24" height="24"><path d="M8 5v14l11-7z" fill="currentColor"/></svg>
                    Iniciar Travesía
                </button>
            </div>
        </div>`;
    document.body.insertAdjacentHTML('afterbegin', modalHTML);

    const modal = document.getElementById('modal-bienvenida');
    const btnComenzar = document.getElementById('btn-comenzar');

    const mapa = window.mapaObjeto;
    const rutasCargadas = window.datosRutas;
    const puntosCargados = window.datosPuntos;

    btnComenzar.addEventListener('click', () => {
        modal.classList.add('oculto');
        
        mapa.eachLayer((layer) => {
            if (layer instanceof L.Polyline && layer.options.className === 'linea-ruta') {
                mapa.removeLayer(layer);
            }
        });
        // ------------------------------------
        
        setTimeout(() => {
            const coordenadasLisboa = puntosCargados["Lisboa"].coordinates;
            mapa.flyTo(coordenadasLisboa, 5, { animate: true, duration: 2 });

            mapa.once('moveend', () => {
                marcadorViajeroInstancia = L.marker(coordenadasLisboa, { icon: iconoViajero }).addTo(mapa);
                
                let contenidoLisboa = `<div class="popup-narrativo">${textosHistoricos["Lisboa"]}<br><br><small style="color:#777;">Fuente: <a href="https://es.wikipedia.org/wiki/Primera_traves%C3%ADa_a%C3%A9rea_del_Atl%C3%A1ntico_sur" target="_blank" style="color: inherit; text-decoration: none;">Wikipedia</a></small></div>`;
                contenidoLisboa += `<br><button id="btn-avanzar-inicio" style="width:100%; background:#2c3e50; color:white; border:none; padding:6px; cursor:pointer; border-radius:3px; font-weight:bold;">Continuar viaje</button>`;

                const popupInicial = L.popup({ maxWidth: 320, closeOnClick: false, closeButton: false })
                    .setLatLng(coordenadasLisboa)
                    .setContent(contenidoLisboa)
                    .openOn(mapa);

                let viajeIniciado = false;
                const iniciarVueloAnimado = () => {
                    if (viajeIniciado) return;
                    viajeIniciado = true;
                    mapa.closePopup(popupInicial);
                    animarTrayectos(mapa, marcadorViajeroInstancia, rutasCargadas, puntosCargados);
                };

                setTimeout(() => {
                    const btnInicio = document.getElementById("btn-avanzar-inicio");
                    if (btnInicio) btnInicio.addEventListener('click', iniciarVueloAnimado);
                }, 100);
            });
        }, 500);
    });
}

function animarTrayectos(mapa, marcador, rutas, mapaPuntos) {
    let indiceTrayecto = 0;
    const velocidadPixelsPorSegundo = 150; 

    function ejecutarSiguienteTramo() {
        if (indiceTrayecto >= rutas.length) return;

        const trayecto = rutas[indiceTrayecto];
        const origen = mapaPuntos[trayecto.from];
        const destino = mapaPuntos[trayecto.to];

        if (!origen || !destino) return;

        const nuevaLinea = L.polyline([origen.coordinates, destino.coordinates], {
            className: 'linea-animada'
        }).addTo(mapa);
        capasRutasDibujadas.push(nuevaLinea);

        const pOrigen = origen.coordinates;
        const pDestino = destino.coordinates;

        const puntoA = mapa.latLngToLayerPoint(pOrigen);
        const puntoB = mapa.latLngToLayerPoint(pDestino);
        const distanciaPixels = puntoA.distanceTo(puntoB);
        
        const duracionTramo = Math.max(1000, (distanciaPixels / velocidadPixelsPorSegundo) * 1000);

        mapa.panTo(pDestino, { animate: true, duration: duracionTramo / 1000 });

        let inicioTiempo = null;

        function darPasoAnimacion(tiempoActual) {
            if (!inicioTiempo) inicioTiempo = tiempoActual;
            const progreso = (tiempoActual - inicioTiempo) / duracionTramo;

            if (progreso < 1) {
                const latIntermedia = pOrigen[0] + (pDestino[0] - pOrigen[0]) * progreso;
                const lngIntermedia = pOrigen[1] + (pDestino[1] - pOrigen[1]) * progreso;
                marcador.setLatLng([latIntermedia, lngIntermedia]);
                requestAnimationFrame(darPasoAnimacion);
            } else {
                marcador.setLatLng(pDestino);
                finalizarTramo(destino);
            }
        }

        requestAnimationFrame(darPasoAnimacion);
    }

    function finalizarTramo(destino) {
        const nombreDestino = destino.name;
        let contenidoPopup = "";
        const esUltimoDestino = (indiceTrayecto === rutas.length - 1);

        if (textosHistoricos[nombreDestino]) {
            contenidoPopup = `<div class="popup-narrativo">${textosHistoricos[nombreDestino]}<br><br><small style="color:#777;">Fuente: <a href="https://es.wikipedia.org/wiki/Primera_traves%C3%ADa_a%C3%A9rea_del_Atl%C3%A1ntico_sur" target="_blank" style="color: inherit; text-decoration: none;">Wikipedia</a></small></div>`;
        } else {
            contenidoPopup = `<div class="popup-narrativo" style="text-align:center; padding: 15px 0 5px 0;"><b>Llegada a ${nombreDestino}</b></div>`;
        }

        const idBoton = "btn-avanzar-" + indiceTrayecto;
        if (esUltimoDestino) {
            contenidoPopup += `<br><button id="${idBoton}" style="width:100%; background:#c0392b; color:white; border:none; padding:6px; cursor:pointer; border-radius:3px; font-weight:bold;">Finalizar travesía</button>`;
        } else {
            contenidoPopup += `<br><button id="${idBoton}" style="width:100%; background:#2c3e50; color:white; border:none; padding:6px; cursor:pointer; border-radius:3px; font-weight:bold;">Continuar viaje</button>`;
        }

        const popup = L.popup({ maxWidth: 320, closeOnClick: false, closeButton: false })
            .setLatLng(destino.coordinates)
            .setContent(contenidoPopup)
            .openOn(mapa);

        const avanzarHandler = () => {
            mapa.closePopup(popup);
            
            if (esUltimoDestino) {
                if (marcadorViajeroInstancia) mapa.removeLayer(marcadorViajeroInstancia);
                capasRutasDibujadas.forEach(linea => mapa.removeLayer(linea));
                capasRutasDibujadas = [];
                const modal = document.getElementById('modal-bienvenida');
                modal.classList.remove('oculto');
            } else {
                indiceTrayecto++;
                ejecutarSiguienteTramo();
            }
        };

        setTimeout(() => {
            const btn = document.getElementById(idBoton);
            if (btn) btn.addEventListener('click', avanzarHandler);
        }, 100);
    }

    ejecutarSiguienteTramo();
}

window.addEventListener('mapaBaseListo', () => {
    inicializarCapaNarrativa();
});